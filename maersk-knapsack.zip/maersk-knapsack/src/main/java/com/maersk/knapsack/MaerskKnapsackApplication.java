package com.maersk.knapsack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaerskKnapsackApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaerskKnapsackApplication.class, args);
	}

}
