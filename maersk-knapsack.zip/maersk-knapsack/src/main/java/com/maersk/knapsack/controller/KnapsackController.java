package com.maersk.knapsack.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.maersk.knapsack.document.KnapsackDocument;

@RestController
public class KnapsackController {

    @Autowired
    private MongoTemplate mongoTemplate;
    @Autowired
    private KafkaTemplate<String, KnapsackDocument> kafkaTemplate;

    
	@GetMapping("/knapsack/{id}")
	public KnapsackDocument  getResult(@PathVariable String id) {
		KnapsackDocument document = mongoTemplate.findOne(Query.query(Criteria.where("task").is(id)),KnapsackDocument.class, "knapsack");
		return document;
	}
	
    @PostMapping(
		  value = "/knapsack", consumes = "application/json",
		  produces = "application/json")
	public KnapsackDocument knapsack(@RequestBody KnapsackDocument problem) {
	    System.out.println(problem);
	    KnapsackDocument document = new KnapsackDocument();
	    document.setProblem(problem.getProblem());
	    document.setStatus("submitted");
	    document.setSubmitionTime((new Date()).getTime());
	    document =   mongoTemplate.insert(document,"knapsack");
	    
	    kafkaTemplate.send("knapsack",  document.getTask(),document);
	    
	    return document;
	}
}
