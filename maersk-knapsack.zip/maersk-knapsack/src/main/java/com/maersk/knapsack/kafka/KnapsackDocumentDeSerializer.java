//package com.maersk.knapsack.kafka;
//
//import java.util.Map;
//
//import org.apache.kafka.common.serialization.Deserializer;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.maersk.knapsack.document.KnapsackDocument;
//
//public class KnapsackDocumentDeSerializer implements Deserializer<KnapsackDocument> {
//
//	  @Override public void close() {
//
//	  }
//
//	  @Override public void configure(Map<String, ?> arg0, boolean arg1) {
//
//	  }
//
//	  @Override
//	  public KnapsackDocument deserialize(String arg0, byte[] arg1) {
//	    ObjectMapper mapper = new ObjectMapper();
//	    KnapsackDocument document = null;
//	    try {
//	      document = mapper.readValue(arg1, KnapsackDocument.class);
//	    } catch (Exception e) {
//
//	      e.printStackTrace();
//	    }
//	    return document;
//	  }
//
//	}