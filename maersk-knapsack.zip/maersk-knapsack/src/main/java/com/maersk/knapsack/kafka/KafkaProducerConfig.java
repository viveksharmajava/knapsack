package com.maersk.knapsack.kafka;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import com.maersk.knapsack.document.KnapsackDocument;

@Configuration
public class KafkaProducerConfig {
	@Value(value = "${kafka.bootstrap.host}")
    private String bootstrapAddress;
	 @Value(value = "${kafka.bootstrap.port}")
	 private String kafkaPort;
    @Bean
    public ProducerFactory<String, KnapsackDocument> producerFactory() {
        Map<String, Object> configProps = new HashMap<>();
       
        configProps.put(
          ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, 
          bootstrapAddress+":"+kafkaPort);
        configProps.put(
          ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, 
          StringSerializer.class);
        configProps.put(
          ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, 
          KnapsackDocumentSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }

    @Bean
    public KafkaTemplate<String, KnapsackDocument> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }
}