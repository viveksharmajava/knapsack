package com.maersk.knapsack.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.maersk.knapsack.document.KnapsackDocument;

public interface KnapsackDocumentRepository extends MongoRepository<KnapsackDocument, String> {

}
