package com.maersk.knapsack.document;

import java.util.Arrays;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Problem {
	
	private int capacity;
	private int [] weights;
	private int [] values;
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public int[] getWeights() {
		return weights;
	}
	public void setWeights(int[] weights) {
		this.weights = weights;
	}
	public int[] getValues() {
		return values;
	}
	public void setValues(int[] values) {
		this.values = values;
	}
	@Override
	public String toString() {
		return "Problem [capacity=" + capacity + ", weights=" + Arrays.toString(weights) + ", values="
				+ Arrays.toString(values) + "]";
	}
	
}
