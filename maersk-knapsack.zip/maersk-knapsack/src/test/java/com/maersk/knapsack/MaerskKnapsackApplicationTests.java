package com.maersk.knapsack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaerskKnapsackApplicationTests {

	@Test
	void contextLoads() {
	}

}
