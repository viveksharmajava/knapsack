package com.maersk.knapsacksolution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KnapsackSolutionApplicationTests {

	@Test
	void contextLoads() {
	}

}
