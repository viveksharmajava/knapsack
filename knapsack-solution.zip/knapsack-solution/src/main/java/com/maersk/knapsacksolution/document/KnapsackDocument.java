package com.maersk.knapsacksolution.document;

import java.util.Arrays;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class KnapsackDocument {
	
	@Id
	private String task;
	private String status;
	private timestamps timestamps;
	private Problem problem;
	private solution solution;
	
	public KnapsackDocument() {
		this.timestamps = new timestamps();
		this.solution = new solution();
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public timestamps getTimestamps() {
		return timestamps;
	}
	public void setTimestamps(timestamps timestamps) {
		this.timestamps = timestamps;
	}
	public Problem getProblem() {
		return problem;
	}
	public void setProblem(Problem problem) {
		this.problem = problem;
	}
	public solution getSolution() {
		return solution;
	}
	public void setSolution(solution solution) {
		this.solution = solution;
	}
	
	public void setStartTime(long time) {
		this.timestamps.started = time;
	}
	public void setSubmitionTime(long time) {
		this.timestamps.submitted = time;
	}
	public void setCompletionTime(long time) {
		this.timestamps.completed = time;
	}
	public void setPackedItems(int [] packed) {
		this.solution.setPacked_items(packed);
	}
	public void setPackedItemsValue(long value) {
		this.solution.setTotal_value(value);
	}
	@Override
	public String toString() {
		return "KnapsackDocument [task=" + task + ", status=" + status + ", timestamps=" + timestamps + ", problem="
				+ problem + ", solution=" + solution + "]";
	}
	
}
@Document
 class timestamps{
    Long submitted;
    Long started;
    Long completed;
	@Override
	public String toString() {
		return "timestamps [submitted=" + submitted + ", started=" + started + ", completed=" + completed + "]";
	}
	public Long getSubmitted() {
		return submitted;
	}
	public void setSubmitted(Long submitted) {
		this.submitted = submitted;
	}
	public Long getStarted() {
		return started;
	}
	public void setStarted(Long started) {
		this.started = started;
	}
	public Long getCompleted() {
		return completed;
	}
	public void setCompleted(Long completed) {
		this.completed = completed;
	}
    
}
@Document
 class solution{
		int [] packed_items;
		Long total_value;
		public int[] getPacked_items() {
			return packed_items;
		}
		public void setPacked_items(int[] packed_items) {
			this.packed_items = packed_items;
		}
		public Long getTotal_value() {
			return total_value;
		}
		public void setTotal_value(Long total_value) {
			this.total_value = total_value;
		}
		@Override
		public String toString() {
			return "solution [packed_items=" + Arrays.toString(packed_items) + ", total_value=" + total_value + "]";
		}
		
	}