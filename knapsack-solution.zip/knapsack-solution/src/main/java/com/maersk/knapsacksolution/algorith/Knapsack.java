package com.maersk.knapsacksolution.algorith;

import java.util.TreeSet;

public class Knapsack {

	
 static int max(int a, int b)
    {
        return (a > b) ? a : b;
    }
 
  /*
   *   Solution: Using memorization bottom up approach
   *   also called DP problem.
   *   Values (stored in array `val`)
   *   Weights (stored in array `wt`)
   *   Total number of distinct items `n`
   *   Knapsack capacity `W`
   *   indexes is used to store the item selected in increasing order.
   *   Time complexity O(n.w) and space complexity is also same.
   */

 public static int knapsack(int W, int wt[],
                          int val[], int n,TreeSet<Integer> index)
 {
     int i, w,total_value;
     int K[][] = new int[n + 1][W + 1];

     // Build table K[][] in bottom up manner
     for (i = 0; i <= n; i++) {
         for (w = 0; w <= W; w++) {
             if (i == 0 || w == 0)
                 K[i][w] = 0;
             else if (wt[i - 1] <= w)
                 K[i][w] = Math.max(val[i - 1] +
                           K[i - 1][w - wt[i - 1]], K[i - 1][w]);
             else
                 K[i][w] = K[i - 1][w];
         }
     }

     // stores the result of Knapsack
    int res = K[n][W];
    //System.out.println(res);
    total_value = res;
     w = W;
     for (i = n; i > 0 && res > 0; i--) {

         // either the result comes from the top
         // (K[i-1][w]) or from (val[i-1] + K[i-1]
         // [w-wt[i-1]]) as in Knapsack table. If
         // it comes from the latter one/ it means
         // the item is included.
         if (res == K[i - 1][w])
             continue;
         else {

             // This item is included.
         //    System.out.print(wt[i - 1] + " ");
             index.add(i-1);
             // Since this weight is included its
             // value is deducted
             res = res - val[i - 1];
             w = w - wt[i - 1];
         }
        }
     return total_value;
 }
}
