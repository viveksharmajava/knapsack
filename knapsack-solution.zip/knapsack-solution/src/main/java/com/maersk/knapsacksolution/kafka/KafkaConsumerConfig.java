package com.maersk.knapsacksolution.kafka;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

import com.maersk.knapsacksolution.document.*;
import com.maersk.knapsacksolution.algorith.Knapsack;;

@EnableKafka
@Configuration
public class KafkaConsumerConfig {
	 @Value(value = "${kafka.bootstrap.host}")
     private String bootstrapAddress;
	 @Value(value = "${kafka.bootstrap.port}")
	 private String kafkaPort;
	 @Value(value = "${kafka.consumer.groupId}")
	 private String groupId;
	 @Autowired
	    private MongoTemplate mongoTemplate;
    @Bean
    public ConsumerFactory<String, KnapsackDocument> consumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(
          ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, 
          bootstrapAddress+":"+kafkaPort);
        props.put(
          ConsumerConfig.GROUP_ID_CONFIG, 
          groupId);
        props.put(
          ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, 
          StringDeserializer.class);
        props.put(
          ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, 
          KnapsackDocumentDeSerializer.class);
        return new DefaultKafkaConsumerFactory<>(props);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, KnapsackDocument> 
      kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, KnapsackDocument> factory =
          new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        return factory;
    }
    @KafkaListener(topics = "knapsack", groupId = "group1")
    public void listenGroupKnapsack(KnapsackDocument document) {
    	
    	document.setStatus("started");
	    document.setStartTime((new Date()).getTime());
	    document =   mongoTemplate.save(document,"knapsack");
	    System.out.println("Received Message before knapsack: " + document);
    	TreeSet <Integer> item_selected = new TreeSet<>();
    	long total_value = Knapsack.knapsack(document.getProblem().getCapacity(), document.getProblem().getWeights(), document.getProblem().getValues(), 
    			                    document.getProblem().getValues().length, item_selected);
    	int []  packed_items = new int[item_selected.size()];
    	int i = 0;
    	for(int item : item_selected) {
    		packed_items[i++] = item;
    	}
    	document.setPackedItems(packed_items);
    	document.setPackedItemsValue(total_value);
    	document.setStatus("completed");
	    document.setCompletionTime((new Date()).getTime());
	    document =   mongoTemplate.save(document,"knapsack");
	    
    }
}
